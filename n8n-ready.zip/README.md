# n8n Bassel Deployment

Ready to deploy on Render.